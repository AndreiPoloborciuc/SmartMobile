const catalog = document.querySelector("#catalog")

const phones = [
    {
        id:1,
        brand: "Apple",
        model: " Iphone 11 Pro",
        image: "https://enter.online/images/product/2023/05/enter-apple-iphone-11-pro-252898.png",
        memory: 64,
        ram: 4,
        price: 15000,
        color: "Black"
    },

    {
        id:2,
        brand: "Apple",
        model: "Iphone 12 Pro",
        image: "https://enter.online/images/product/2023/05/enter-apple-iphone-12-pro-96591.png",
        memory: 128,
        ram: 6,
        price: 20000,
        color: "Black"
    },

    {
        id:3,
        brand: "Apple",
        model: " Iphone 13 Pro",
        image: "https://enter.online/images/product/2022/05/enter-apple-iphone-13-pro-091.png",
        memory: 256,
        ram: 8,
        price: 23000,
        color: "Pink"
    },
    {
        id:4,
        brand: "Samsung",
        model: " Galaxy S23",
        image: "https://enter.online/images/product/2023/02/enter-samsung-galaxy-s23-s911-195116.png",
        memory: 128,
        ram: 6,
        price: 16000,
        color: "Pink"
    },
    {
        id:5,
        brand: "Xiaomi",
        model: "Redmi Note 11 4G",
        image: "https://enter.online/images/product/2023/08/enter-xiaomi-redmi-note-11-4g-76541.png",
        memory: 64,
        ram: 4,
        price: 6000,
        color: "Pink"
    },
    {
        id:6,
        brand: "Xiaomi",
        model: "Redmi Note 10S 4G",
        image: "https://enter.online/images/product/2022/12/enter-xiaomi-redmi-note-10s-1235163.png",
        memory: 128,
        ram: 6,
        price: 5500,
        color: "Green"
    },
    {
        id:7,
        brand: "Ulefone",
        model: "Note 13P 4G",
        image: "https://enter.online/images/product/2023/08/enter-ulefone-note-13p-4g-66632.png",
        memory: 64,
        ram: 4,
        price: 4000,
        color: "Silver"
    },
    {
        id:8,
        brand: "Ulefone",
        model: "Armor 8 Pro 4G",
        image: "https://enter.online/images/product/2023/08/enter-ulefone-armor-8-pro-4g-26241.png",
        memory: 256,
        ram: 8,
        price: 12000,
        color: "Silver"
    },
    {
        id:9,
        brand: "Ulefone",
        model: "Armor 14 4G",
        image: "https://enter.online/images/product/2023/08/enter-ulefone-armor-14-4g-51870.png",
        memory: 128,
        ram: 6,
        price: 8000,
        color: "Silver"
    },
    {
        id:10,
        brand: "Apple",
        model: "iPhone SE 2020 4G",
        image: "https://enter.online/images/product/2023/05/enter-apple-iphone-se-2020-107626.webp",
        memory: 128,
        ram: 6,
        price: 10999,
        color: "Black"
    },
    {
        id:11,
        brand: "Apple",
        model: "iPhone 14 Pro Max 5G",
        image: "https://enter.online/images/product/2023/05/enter-apple-iphone-14-pro-max-140352.webp",
        memory: 256,
        ram: 6,
        price: 29999,
        color: "Silver"
    },
    {
        id:12,
        brand: "Xiaomi",
        model: "Redmi Note 10 Pro 4G",
        image: "https://enter.online/images/product/2022/12/enter-xiaomi-redmi-note-10-pro-730876.webp",
        memory: 64,
        ram: 4,
        price: 5199,
        color: "Silver"
    },
    {
        id:13,
        brand: "Samsung",
        model: "Galaxy A12 4G A125",
        image: "https://enter.online/images/product/2022/12/enter-samsung-galaxy-a12-a125-7666172.webp",
        memory: 256,
        ram: 8,
        price: 2599,
        color: "Black"
    },
    {
        id:14,
        brand: "Samsung",
        model: "Galaxy M32 4G M325",
        image: "https://enter.online/images/product/2022/12/enter-samsung-galaxy-m32-m325-2035031.webp",
        memory: 64,
        ram: 4,
        price: 5599,
        color: "Black"
    },
    {
        id:15,
        brand: "Samsung",
        model: "Galaxy A32",
        image: "https://enter.online/images/product/2022/12/enter-samsung-galaxy-a32-a325-14676.webp",
        memory: 128,
        ram: 4,
        price: 6999,
        color: "Black"
    },
    
]

phones.forEach((phone) => {
    catalog.innerHTML += `
       <div class='phones'>
            <img src='${phone.image}'>
            <div>
               <h3> ${phone.brand}</h3>
               <h4> ${phone.model}</h4>
               <p> ${phone.price} MDL </p>
            </div>
        </div>
    `
})


let images = ["https://images.pexels.com/photos/799443/pexels-photo-799443.jpeg?auto=compress&cs=tinysrgb&w=600", "https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "https://images.pexels.com/photos/879117/pexels-photo-879117.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "https://images.pexels.com/photos/1786433/pexels-photo-1786433.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "https://images.pexels.com/photos/583842/pexels-photo-583842.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "https://images.pexels.com/photos/47261/pexels-photo-47261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "https://images.unsplash.com/photo-1546054454-aa26e2b734c7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1780&q=80", "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1858&q=80", "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1780&q=80", "https://images.unsplash.com/photo-1610664921890-ebad05086414?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"]

const slider = document.querySelector("#slider")
const btnLeft = document.querySelector("#btn-left")
const btnRight = document.querySelector("#btn-right")

let slideImg = 0
slider.style.backgroundImage = `url(${images[slideImg]})`

btnRight.addEventListener("click", () => {
    slideImg = slideImg >= images.length -1 ? 0 : slideImg +1
    slider.style.backgroundImage = `url(${images[slideImg]})`
})

btnLeft.addEventListener("click", () =>{
    slideImg = slideImg === 0 ? images.length - 1 : slideImg -1
    slider.style.backgroundImage = `url(${images[slideImg]})`
})

function updateSlider() {
    slider.style.backgroundImage = `url(${images[slideImg]})`;
}

const intervalX = setInterval(() => {
    slideImg = slideImg >= images.length - 1 ? 0 : slideImg + 1;
    updateSlider();
}, 2000)

btnRight.addEventListener("click", () => {
    clearInterval(intervalX);
})

btnLeft.addEventListener("click", () => {
    clearInterval(intervalX);
})


const filtru = document.querySelectorAll(".filtru")
const optiuni = document.querySelectorAll(".optiuni")

filtru.forEach((filtru1, idx) => {
    filtru1.addEventListener("click", () => {
        optiuni[idx].style.height = optiuni[idx].style.height === "auto" ? "0px" : "auto"
        optiuni[idx].style.padding = optiuni[idx].style.padding === "10px" ? "0px" : "10px"
        optiuni[idx].style.left = optiuni[idx].style.left === "0px" ? "-500px" : "0px"
        filtru1.firstElementChild.src = filtru1.firstElementChild.src === "https://iconmonstr.com/wp-content/g/gd/makefg.php?i=../releases/preview/7.2.0/png/iconmonstr-caret-down-circle-filled.png&r=0&g=0&b=0" ? "https://creazilla-store.fra1.digitaloceanspaces.com/icons/3205270/caret-up-circle-icon-sm.png" : "https://iconmonstr.com/wp-content/g/gd/makefg.php?i=../releases/preview/7.2.0/png/iconmonstr-caret-down-circle-filled.png&r=0&g=0&b=0"
    })
})


const DelaInp = document.querySelector("#de_la")
const PanaLaInp = document.querySelector("#pana_la")
const brandCheckboxes = document.getElementsByName("brand")
const colorCheckboxes = document.getElementsByName("color")
const memInt = document.getElementsByName("mem-int")
const ram = document.getElementsByName("RAM")


const filters =
    {
        brands: [],
        pretMin: 0,
        pretMax: 0,
        colors: [],
        memorieIn : [],
        memRAM: []

    }
   
DelaInp.addEventListener("input", () => {
    filters.pretMin =Number(DelaInp.value)
    smartFilter(phones, filters)
    
})

PanaLaInp.addEventListener("input", () => {
    filters.pretMax =Number(PanaLaInp.value)
    smartFilter(phones, filters)

})


brandCheckboxes.forEach(checkbox => {
    checkbox.addEventListener("click", () =>{
        if(checkbox.checked){
            filters.brands.push(checkbox.value)
        }else{
            filters.brands.splice(filters.brands.indexOf(checkbox.value), 1)
        }

        smartFilter(phones, filters)
        
    })
})

colorCheckboxes.forEach(checkbox => {
    checkbox.addEventListener("click", () =>{
        if(checkbox.checked){
            filters.colors.push(checkbox.value)
        }else{
            filters.colors.splice(filters.colors.indexOf(checkbox.value), 1)
        }

        smartFilter(phones, filters)

        
    })

})

memInt.forEach(checkbox => {
    checkbox.addEventListener("click", () =>{
        if(checkbox.checked){
            filters.memorieIn.push(checkbox.value)
        }else{
            filters.memorieIn.splice(filters.memorieIn.indexOf(checkbox.value), 1)
        }
        smartFilter(phones, filters)
    })
})

ram.forEach(checkbox => {
    checkbox.addEventListener("click", () =>{
        if(checkbox.checked){
            filters.memRAM.push(checkbox.value)
        }else{
            filters.memRAM.splice(filters.memRAM.indexOf(checkbox.value), 1)
        }
        smartFilter(phones, filters)

    })
})

function smartFilter(data, filters) {
    let filteredData = data;

    if (filters.pretMin > 0) {
        filteredData = filteredData.filter(item => item.price >= filters.pretMin);
    }

    if (filters.pretMax > 0) {
        filteredData = filteredData.filter(item => item.price <= filters.pretMax);
    }

    if (filters.brands.length > 0) {
        filteredData = filteredData.filter(item => filters.brands.includes(item.brand));
    }

    if (filters.colors.length > 0) {
        filteredData = filteredData.filter(item => filters.colors.includes(item.color));
    }

    if (filters.memorieIn.length > 0) {
        filteredData = filteredData.filter(item => filters.memorieIn.includes(String(item.memory)));
    }

    if (filters.memRAM.length > 0) {
        filteredData = filteredData.filter(item => filters.memRAM.includes(String(item.ram)));
    }

    smartDisplay(filteredData, catalog)
}

smartDisplay(filteredData, catalog)


function smartDisplay(filteredData, el){
    el.innerHTML = ""

    filteredData.forEach(item =>{
        el.innerHTML += `
        <div class='phones'>
            <img src='${item.image}'>
            <div>
               <h3> ${item.brand}</h3>
               <h4> ${item.model}</h4>
               <p> ${item.price} MDL </p>
            </div>
        </div>
        `
    })
}













// document.getElementById("search").addEventListener("keyup", (e) => searchCar(e))

// function searchCar (e){
//     if(e.key === "Enter"){
//         const userSearch = e.target.value
//         const searchResults = cars.filter(car => {
//         const fullname = (car.brand) + " " + (car.model)
//         const search = userSearch.split(" ")
//         for ( let i = 0; i < search.length; i++){
//             if(fullname.includes(search[i])) return car
//     }
    
// })
// console.log(searchResults)
// }
// }










// const cart = document.querySelector("#cart")

// cars.forEach(car => {
//     catalog.innerHTML += `
//     <p> ${car.brand} ${car.model}</p>
//     <button class='cart-btn' onclick='addToCart(${car.id})'> Add to cart </button>
//     `
// })

// const cartArray = []

// function addToCart(id){
//     if(cartArray.find(car => car.id === id)){
//         alert("Este deja in cos !!!")
//         return
//     }
//     cartArray.push(cars.find(car => car.id === id))
//     cart.innerHTML = ""
//     cartArray.forEach(car => {
//         cart.innerHTML += `<p>${car.brand} ${car.model}}</p>`
//     })
// }








// Burger BTN = document.querry selector
// Burger menu= document.querry selector
//burgerBtn.addeventlistener("click", () => {
//     burgerMenu.style.height = burgermenu.style.height === "150px" ? "0px" : "150px"

// })


//cartBtn = document.querry selector
//cartmenu = document.querry selector
//cartbtn.addeventlistener("click", () => {
//     cartMenu.style.height = cartmenu.style.height === "150px" ? "0px" : "150px"

// })





// const cityInput = document.getElementById("cityInput")

// cityInput.addEventListener("keyup", (e) =>{

//    if(e.key === "Enter") {

//    const city = cityInput.value
//    const key = "21952e504c317bb839126494bf193a15"
//    const API = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${key}`
//    const box = document.getElementById("box")
//    fetch(API)
//    .then(res => res.json())
//    .then(data => {
//       box.innerHTML = `
//       <h3>${data.name}, ${data.sys.country}</h3>
//       <h1>${Math.round(data.main.temp - 272)} C</h1>
//       <p>Visibility: ${data.visibility/1000} KM</p>
//       <p>${data.weather[0].description}</p>
//       `
//    })
//    }
// })






// Examen pe maine 

// 1. Creati un nav Bar + Burger + responsive 
// 2. Slider  10 img 
// 3. Catalog + filtru + cautare
// 4. Vremea de afara
// 5. API
// 6. Cos de cumparaturi 
// 7. Exemplu de plata (HTML + CSS si JS validarea)
// 8. Animatii
// 9. Responsive
// 10. Oricare functional JS de la voi





